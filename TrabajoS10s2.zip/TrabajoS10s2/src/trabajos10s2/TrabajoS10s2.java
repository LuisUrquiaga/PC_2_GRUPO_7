package Until;

import java.util.LinkedList;
import java.util.Scanner;

public class TrabajoS10s2 {
    private LinkedList<String> tareas;

    public TrabajoS10s2() {
        tareas = new LinkedList<>();
    }

    public void agregarTarea(String tarea) {
        tareas.add(tarea);
        System.out.println("Tarea agregada: " + tarea);
    }

    public void eliminarTarea(String tarea) {
        if (tareas.remove(tarea)) {
            System.out.println("Tarea eliminada: " + tarea);
        } else {
            System.out.println("Tarea no encontrada: " + tarea);
        }
    }

    public void mostrarTareas() {
        System.out.println("Lista de tareas:");
        for (String tarea : tareas) {
            System.out.println("- " + tarea);
        }
    }

    public boolean buscarTarea(String tarea) {
        return tareas.contains(tarea);
    }

    public LinkedList<String> crearPilaPrioridad() {
        LinkedList<String> pila = new LinkedList<>();
        for (int i = tareas.size() - 1; i >= 0; i--) {
            pila.push(tareas.get(i));
        }
        return pila;
    }

    public static void main(String[] args) {
        TrabajoS10s2 app = new TrabajoS10s2();
        Scanner scanner = new Scanner(System.in);
        String opcion;

        do {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Agregar Tarea");
            System.out.println("2. Eliminar Tarea");
            System.out.println("3. Mostrar Tareas");
            System.out.println("4. Buscar Tarea");
            System.out.println("5. Crear Pila de Tareas");
            System.out.println("0. Salir");
            opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("Ingrese la tarea: ");
                    String tareaAgregar = scanner.nextLine();
                    app.agregarTarea(tareaAgregar);
                    break;
                case "2":
                    System.out.print("Ingrese la tarea a eliminar: ");
                    String tareaEliminar = scanner.nextLine();
                    app.eliminarTarea(tareaEliminar);
                    break;
                case "3":
                    app.mostrarTareas();
                    break;
                case "4":
                    System.out.print("Ingrese la tarea a buscar: ");
                    String tareaBuscar = scanner.nextLine();
                    boolean encontrada = app.buscarTarea(tareaBuscar);
                    System.out.println(encontrada ? "Tarea encontrada." : "Tarea no encontrada.");
                    break;
                case "5":
                    LinkedList<String> pila = app.crearPilaPrioridad();
                    System.out.println("Pila de tareas según prioridad:");
                    for (String tarea : pila) {
                        System.out.println("- " + tarea);
                    }
                    break;
                case "0":
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (!opcion.equals("0"));

        scanner.close();
    }
}