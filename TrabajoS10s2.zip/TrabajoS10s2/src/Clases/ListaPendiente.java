package Clases;

import java.util.ArrayList;
import java.util.List;

public class ListaPendiente {
    private List<Tarea> tareas; // Lista para almacenar las tareas

    public ListaPendiente() {
        tareas = new ArrayList<>(); // Inicializa la lista de tareas
    }

    // Método para agregar una tarea
    public void agregarTarea(int id, String nombre) {
        tareas.add(new Tarea(id, nombre));
        System.out.println("Tarea agregada: " + nombre);
    }

    // Método para eliminar una tarea
    public void eliminarTarea(int id) {
        tareas.removeIf(tarea -> tarea.getId() == id);
        System.out.println("Tarea eliminada con ID: " + id);
    }

    // Método para mostrar todas las tareas
    public void mostrarTareas() {
        System.out.println("Lista de tareas:");
        for (Tarea tarea : tareas) {
            System.out.println("- ID: " + tarea.getId() + ", Nombre: " + tarea.getNombre());
        }
    }
    
    public static void main(String[] args) {
        ListaPendiente lista = new ListaPendiente();
        lista.agregarTarea(1, "Hacer la compra");
        lista.agregarTarea(2, "Estudiar para el examen");
        lista.mostrarTareas();
        lista.eliminarTarea(1);
        lista.mostrarTareas();
    }
}

// Clase interna para representar una tarea
class Tarea {
    private int id;
    private String nombre;

    public Tarea(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }
}