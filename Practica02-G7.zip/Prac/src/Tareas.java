
public class Tareas {
    private String nombre;
    private Tareas siguiente;

    public Tareas(String nombre) {
        this.nombre = nombre;
        this.siguiente = null;
    }

    public String getNombre() {
        return nombre;
    }

    public Tareas getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Tareas siguiente) {
        this.siguiente = siguiente;
    }
}