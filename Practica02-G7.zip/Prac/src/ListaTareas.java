
import java.util.Stack;

public class ListaTareas {
    Tareas cabeza;

    public ListaTareas() {
        cabeza = null;
    }

    public void agregarTarea(String nombre) {
        Tareas nuevaTarea = new Tareas(nombre);
        nuevaTarea.setSiguiente(cabeza);
        cabeza = nuevaTarea;
    }

    public void eliminarTarea(String nombre) {
        Tareas actual = cabeza;
        Tareas anterior = null;

        while (actual != null && !actual.getNombre().equals(nombre)) {
            anterior = actual;
            actual = actual.getSiguiente();
        }

        if (actual != null) {
            if (anterior == null) {
                cabeza = actual.getSiguiente();
            } else {
                anterior.setSiguiente(actual.getSiguiente());
            }
        }
    }

    public void mostrarTareas() {
        Tareas actual = cabeza;
        while (actual != null) {
            System.out.println(actual.getNombre());
            actual = actual.getSiguiente();
        }
    }

    public boolean buscarTarea(String nombre) {
        Tareas actual = cabeza;
        while (actual != null) {
            if (actual.getNombre().equals(nombre)) {
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    public Stack<Tareas> crearPilaPrioridad() {
        Stack<Tareas> pila = new Stack<>();
        Tareas actual = cabeza;
        while (actual != null) {
            pila.push(actual);
            actual = actual.getSiguiente();
        }
        return pila;
    }
}
